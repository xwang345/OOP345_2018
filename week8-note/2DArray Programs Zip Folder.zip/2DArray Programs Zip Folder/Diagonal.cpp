#include <iostream>
using namespace std;

const int n = 5;
void Diagonals(int A[3][3], int);
void display(int number[3][3]);
int main()
{
	int number[3][3];
	int row, col;
	int n = 3;
	cout << "Enter the Elements in Array: " << endl;
	for (row = 0; row < 3; row++)
	{
		for (col = 0; col < 3; col++)
		{
			cout << "Array Index [" << row << "] [" << col << "]: ";
			cin >> number[row][col];
		}
		cout << endl;
	}
	display(number);
	Diagonals (number, n);
	cout << endl;
	return 0;
}


void Diagonals(int A[3][3], int n)
{
	int i, j;
	cout << endl;
	cout << "Diagonal One: "<< endl;
	for (i = 0; i<n; i++)
		cout << A[i][i] << " "<<endl;
	cout << endl;
	cout << "Diagonal Two: " <<endl;
	for (i = 0; i < n; i++)
		cout << A[i][n - (i + 1)] << " " << endl;
}

void display(int number[3][3])
{
	int row, col;
	cout << "The Elements in Array are: " << endl;
	for (row = 0; row < 3; row++)
	{
		for (col = 0; col < 3; col++)
		{
			cout << number[row][col] << "\t";
		}
		cout << endl;
	}
}

