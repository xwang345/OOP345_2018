#include <iostream>
using namespace std;
//#define Rowsize 3;
//#define colsize 4;

void SumRow(int[3][3]);
void SumColumn(int[3][3]);

int main()
{
	int numbers [][3] = { {2,4,6}, {8,10,12}, {1,3,9} };
	int total = 0;
	
	for (int row = 0; row < 3; row++)
	{
		for (int col = 0; col < 3; col++)
		{
			total += numbers[row][col];
		}
	}

	cout << "The Total of Array is: " <<total<< endl;
	
	SumRow(numbers);
	SumColumn(numbers);

	cout << endl;
	return 0;

}

void SumRow(int num[3][3])
{
	int total;
	for (int row = 0; row < 3; row++)
	{
		total = 0;
		for (int col = 0; col < 3; col++)
		{
			total += num[row][col];
		}
		cout << "The Total of Row is: " << total << endl;
	}
	cout << endl;
}

void SumColumn(int num[3][3])
{
	int total;
	for (int col = 0; col < 3; col++)
	{
		total = 0;
		for (int row = 0; row < 3; row++)
		{
			total += num[row][col];
		}
		cout << "The Total of Column is: " << total << endl;
	}
	cout << endl;
}
