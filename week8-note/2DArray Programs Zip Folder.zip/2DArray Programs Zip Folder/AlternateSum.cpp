#include <iostream>
using namespace std;

int AlterSum (int num[][3]);
void display (int number[3][3]);

int main()
{
	int number[3][3];
	int row, col;

	cout << "Enter the Elements in Array: " << endl;
	for (row = 0; row < 3; row++)
	{
		for (col = 0; col < 3; col++)
		{
			cout << "Array Index [" << row << "] [" << col << "]: ";
			cin >> number[row][col];
		}
		cout << endl;
	}
	int sum;
	sum = AlterSum (number);
	display(number);
	cout << endl << "The Sum of Elements from All Alternate Elements: " << sum << endl;
	cout << endl;
	return 0;
}

int AlterSum (int B[][3])
{
	int sum = 0;
	for (int I = 0; I<3; I++)
	{
		for (int J = 0; J < 3; J++)
		{
			if ((I + J) % 2 == 0)
			sum = sum + B[I][J];
		}
	}
	return sum;
}

void display(int number[3][3])
{
	int row, col;
	cout << "The Elements in Array are: " << endl;
	for (row = 0; row < 3; row++)
	{
		for (col = 0; col < 3; col++)
		{
			cout << number[row][col] <<"\t";
		}
		cout << endl;
	}
}