#include <iostream>
using namespace std;

void LowerHalf(int num[][3]);

int main()
{
	int number[3][3];
	int row, col;
	
	cout << "Enter the Elements in Array: " << endl;
	for (row = 0; row < 3; row++)
	{
		for (col = 0; col < 3; col++)
		{
			cout << "Array Index [" << row << "] [" << col << "]: ";
			cin >> number[row][col];
		}
		cout << endl;
	}
	LowerHalf(number);
	cout << endl;
	return 0;
}

void LowerHalf(int num[][3])
{
	int row, col;
	for (row = 0; row < 3; row++)
	{
		for (col = 0; col < 3; col++)
		{
			if (row >= col)
			{
				cout << num[row][col] << " ";
			}
			else
			{
				cout << " ";
			}
		}
		cout << endl;
	}
}