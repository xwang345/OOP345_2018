#include <iostream>
using namespace std;

const int S = 5;
void DisplayMidle(int A[S][S], int S);
void display(int number[S][S], int);

int main()
{
	int number[S][S];
	int row, col;

	cout << "Enter the Elements in Array: " << endl;
	for (row = 0; row < S; row++)
	{
		for (col = 0; col < S; col++)
		{
			cout << "Array Index [" << row << "] [" << col << "]: ";
			cin >> number[row][col];
		}
		cout << endl;
	}
	
	DisplayMidle(number, S);
	cout << endl;
	display(number, S);
	cout << endl;
	return 0;
}


void DisplayMidle(int A[S][S], int S)
{
	int mid = S / 2;
	int i;
	cout <<endl <<" Middle row: ";
	for (i = 0; i<S; i++)
		cout << A[mid][i] << " ";
	cout << endl << "Middle Column: ";
	for (i = 0; i < S; i++)
		cout << A[i][mid] << " ";
		cout << endl;
}


void display(int number[S][S], int S)
{
	int row, col;
	cout << "The Elements in Array are: " << endl;
	for (row = 0; row < S; row++)
	{
		for (col = 0; col < S; col++)
		{
			cout << number[row][col] << "\t";
		}
		cout << endl;
	}
}