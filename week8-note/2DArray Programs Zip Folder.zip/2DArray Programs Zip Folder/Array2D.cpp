#include <iostream>
using namespace std;

int main()
{
	int size;
	cout << "Enter the Row size of an array: ";
	cin >> size;
	const int Rowsize = 4;
	cout << "Enter the Column size of an array: ";
	cin >> size;
	const int Colsize = 4;
	int arry[Rowsize][Colsize];
	cout << "enter the elements in array: ";
	for (int i = 0; i < Rowsize; i++)
	{
		for (int j = 0; j < Colsize; j++)
		{
			cout<<"Array Index [" <<i+1<<"] ["<<j+1<<"]: ";
				cin>>arry[i][j];
		}
	}

	for (int i = 0; i < Rowsize; i++)
	{
		for (int j = 0; j < Colsize; j++)
		{
			cout << "Array Index [" << i + 1 << "] [" << j + 1 << "]: ";
			cout << arry[i][j];
		}
	}
}