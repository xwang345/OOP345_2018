#include <iostream>
using namespace std;

void obtain (float[], int);

int main()
{
	float temp[31];
	int numDays, month, m;
	cout << "Enter the Days: ";
	cin >> numDays;
	obtain(temp, numDays);
	cout << endl;
	return 0;
}

void obtain (float temp[], int days)
{
	cout << "Enter the values in Array: ";
	for (int m = 0; m < days; m++)
	{
		cout << "Array [" << m + 1 << "]: ";
		cin >> temp[m];
	}

	for (int m = 0; m < days; m++)
	{
		cout << "The Values in Array [" << m + 1 << "]: ";
		cout << temp[m] << endl;
	}
}